# JS- Check if a Number is Even or Odd- Task-13

This project is a basic JavaScript program that checks whether a given number is **even or odd** using an `if-else` statement.

---

## ✨ Features

- Checks if a number is even or odd  
- Uses simple `if-else` logic  
- Displays result in the console  
- Beginner-friendly code  

---

## 🛠️ Technologies Used

-HTML5
- JavaScript  

---

## 🎯 How It Works

- The modulus operator `%` is used  
- If `num % 2 == 0` → number is even  
- Otherwise → number is odd  

---

## ▶️ How to Run

1. Clone or download this repository  
2. Open `index.html` in your browser  

---

## 🎓 Purpose

This project helps in understanding:
- Conditional statements (`if-else`)  
- Basic JavaScript syntax  
- Using operators like `%`
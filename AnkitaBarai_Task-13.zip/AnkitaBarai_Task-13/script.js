//JS- Check if a Number is Even or Odd- Task-13

let num = 12;

// Check even or odd using if-else
if(num%2 == 0){
    console.log(`The number ${num} is even.`);
}else{
    console.log(`The number ${num} is odd.`);
}

